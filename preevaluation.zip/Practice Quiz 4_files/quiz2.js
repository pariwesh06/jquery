Questions = 10;

a1 = new Array("b");
a2 = new Array("a");
a3 = new Array("a", "c");
a4 = new Array("a", "b", "c");
a5 = new Array("a");
a6 = new Array("b");
a7 = new Array("b");
a8 = new Array("b");
a9 = new Array("a");
a10 = new Array("a");
