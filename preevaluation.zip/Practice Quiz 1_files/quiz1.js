Questions = 10;

a1 = new Array("a");
a2 = new Array("c");
a3 = new Array("b");
a4 = new Array("c");
a5 = new Array("c");
a6 = new Array("b");
a7 = new Array("b");
a8 = new Array("a");
a9 = new Array("d");
a10 = new Array("b");