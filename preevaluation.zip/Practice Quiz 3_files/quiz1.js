Questions = 10;

a1 = new Array("a");
a2 = new Array("c");
a3 = new Array("b");
a4 = new Array("b", "c");
a5 = new Array("a");
a6 = new Array("b");
a7 = new Array("a");
a8 = new Array("c");
a9 = new Array("c");
a10 = new Array("a");
