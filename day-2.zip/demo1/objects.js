var a = 1;
var user = {
  salary: 200,
  name: 'Ram',
  address:{
    street:'1st Main',
    zip:432423
  },
  work:function(){//method
    console.log('working');
  }
} //JSON objects 
user.work();
//new Object({salary:300});
console.log(user.address.street);
user.name = "Pariwesh";
user.age = 34;
console.log(user);
delete user.age;
console.log(user);

function createUsers(){
  var users=[];
  for(var i=0;i<5;i++){
    users.push({
      name:'ram'+i,
      salary:1000*i
    });
  }
  return users;
}
var result = createUsers();
console.log(result)

