//advanced scope
var a ={};//namespace
a.foo= function(){
  console.log(this);
  return function(){
    console.log('inner',this);
  }.bind(a);
}
a.foo()();
// a.foo.call({name:'ram'});
// a.foo();

//change the context but don't call the function immediately
// var foo1= a.foo.bind({name:"shyam"});



//this represents the object 
// 1.on which the function was called or 
// 2.the object supplied in call().

// //===== scheduling =========
// var id1 = setTimeout(
//   function ()//A
//   {
//     console.log('called timeout')
//   }, 4000);
// clearTimeout(id1);
// for (var i = 0; i < 4; i++) {
//   var id = setInterval(
//     function () //B
//     { console.log('called setInterval', window1) }
//     , 1000 * i);
// }
// console.log(id);


//=====================closure ========
// a = 1;
// function foo() {
//   var a = 2; //local var
//   var b=3;
//   console.log('outer',a);
//   return function () { //closure function
//     // var a=4;
//     console.log('inner', a);
//   }
// }
//  foo()();




// ============Level 1==============
// var a=1; //global variable
// function foo(){
//   a=2; //local var
//   console.log(a);
// }
// function bar(){
//   // var a=2; //local var
//   console.log(a);
// }
// foo();
// bar();