  console.log('hello js...');
var x=1;
console.log(x);

x='Fidelity';
console.log(x);
// var answer = prompt("are you okay?");
// console.log(answer);

var foo = function (age, male, name){
  console.log('logic', arguments);
  console.log(age==arguments[0]);
  return age+20;
}

var numbers = [3,-5,1 ,10,11];
numbers.push(23);
numbers.push('ram');
console.log(numbers.length);
console.log(numbers);

// numbers.pop();
numbers.splice(1,2);
console.log(numbers);

// function algo(a,b){
//   return b-a;
// }
// // numbers.sort(algo);
// console.log(numbers);

// var filtered = numbers.filter(function(element, index){
//   // console.log(index);
//   // return element>0;
//   return index%2==0;
// });

// console.log(filtered);
// console.log(numbers);


// function foo(){
//   console.log('second');
// }
// var result= foo(10);