function validate(){
  console.log(event.target.value.length);
  event.target.style.backgroundColor=event.target.value.trim().length==0?'red':'green';
  var message1 = document.getElementById('message1');
  message1.style.display=event.target.value.trim().length==0?'inline':'none';
}
function save() {
  var firstname = document.getElementById('firstname');
  firstname.style.backgroundColor = 'red';
}
// setInterval(function () {
//   var e = document.createElement('input');
//   document.body.appendChild(e);
// }, 3000);
