var a={};
//namespace packages
a.b={};
a.b.foo= function (){
  console.log('1');
}

a.foo= function (){
  console.log('2');
}
a.b.foo();
a.foo();