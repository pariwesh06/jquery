var firstname = $('#firstname'); //caching
var list = $('ol');
$('#sort').click(function(){
  $('li').sort(function(li1 ,li2 ){
    return $(li1).text() >$(li2).text()?-1:1;
  }).appendTo(list);
});

$('#save').click(function (event) {
  //ajax call 
  $.ajax('http://it-ebooks-api.info/v1/search/' + firstname.val(), {
    error: function () {//error handler
      alert('error occured ,please retry');
    },
    headers: {
      'content-type': 'application/json'
    },
    success: function (responseData) { //success handler, 200 - 399
      list.children().remove();
      $(responseData.Books).each(function (index, book) {
        var row = $('<li>').append(book.Title);
        list.append(row);
      })
    }
  });

  // firstname.addClass(!firstname.val() ? 'danger1' : '');
  // var deleteBtn = $('<button>').html('X');
  // deleteBtn.click(function () {
  //   $(this).parent().remove();
  // })
  // row.append(deleteBtn);
})

// var elements = $('input');
// console.log(elements.length)
// elements.css('backgroundColor', 'red');
// elements.addClass('danger1');
// console.log(elements.hasClass('danger'));

// $( "li" ).eq( 2 ).css( "background-color", "red" );
// $( "li:eq(2)" ).css( "background-color", "red" );