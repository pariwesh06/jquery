var elements = $('input');
console.log(elements.length)
// elements.css('backgroundColor', 'red');
elements.addClass('danger1');
// console.log(elements.hasClass('danger'));

// $( "li" ).eq( 2 ).css( "background-color", "red" );
// $( "li:eq(2)" ).css( "background-color", "red" );